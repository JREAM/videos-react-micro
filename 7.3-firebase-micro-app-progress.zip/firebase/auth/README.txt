# TEMPLATE

This is a base template to follow along with building Micro-Apps in React.
We are using a minimal CSS framework called [milligram.io](https://milligram.io).

- **Noticable Changes**
  - Using `constants.js` for repeatable items.
  - Using `milligram.io` for small css.
  - PropTypes: Not Required (`.eslintrc`)
  - Testing: Added (Not Required, unless taught otherwise)
    - Run: `yarn test` to test the default `App.js` to ensure the full page renders,
      It is faster than starting the App. Shallow is to exclude App Children, I'm not
      using it because this is so tiny.

---

Open Source MIT

(C) 2019 Jesse Boyer
