import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import ErrorBoundary from './components/ErrorBoundary';

// Constants
import { PATH } from './constants';

// Pages
import Home from './pages/Home';
import Login from './pages/Login';
import Status from './pages/Status';

export default class App extends Component {

  render = () => (
    <BrowserRouter>
      <Switch>
        <ErrorBoundary>
          <Route exact path={PATH.HOME} component={Home} />
          <Route path={PATH.STATUS} component={Status} />
          <Route path={PATH.LOGIN} component={Login} />
        </ErrorBoundary>
      </Switch>
    </BrowserRouter>
    )

}
