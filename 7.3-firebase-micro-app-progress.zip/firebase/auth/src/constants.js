export const PATH = {
  HOME: '/',
  LOGIN: '/login',
  STATUS: '/status',
};

export default {};
