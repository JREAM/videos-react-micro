import firebase from 'firebase/app';

const config = {
  apiKey: 'YourCredentials',
  authDomain: 'YourCredentials.firebaseapp.com',
  databaseURL: 'https://YourCredentials.firebaseio.com',
  projectId: 'YourCredentials',
  storageBucket: 'YourCredentials.appspot.com',
  messagingSenderId: 'YourCredentials'
};

const getInstance = (config) => {
  if (instance) {
    return instance;
  }
  return firebase.initializeApp(config);
};

let instance = getInstance(config);
