import firebase from 'firebase/app';
import 'firebase/auth';

/**
 * Login
 * @param {string} provider   string
 * @param {string} mode       (Default: popup) [popup|redirect]
 */
const login = async (provider, mode='popup') => {
  try {
    // REQUIRE: Must pass the mode to login
    const VALID_MODES = [ 'popup', 'redirect' ];
    if (!VALID_MODES.includes(mode)) {
      throw Error ('Invalid mode, use popup or redirect');
    }

    // REQUIRED: Must pass a valid provider
    // eg: new firebase.auth.GoogleAuthProvider()
    const authProvider = getAuthProvider(provider);
    if (mode === 'popup') {
      // @TODO set some kind of session/state/data/etc
      return await firebase.auth().signInWithPopup(new authProvider());
    }
    // @TODO set some kind of session/state/data/etc
    return await firebase.auth().signInWithRedirect(new authProvider());
  } catch (error) {
    alert(error);
  }
};

const getAuthProvider = (provider) => {
  switch (provider) {
    case 'google':
      return firebase.auth.GoogleAuthProvider;
    case 'github':
      return firebase.auth.GithubAuthProvider;
    case 'facebook':
      return firebase.auth.FacebookAuthProvider;
    case 'twitter':
      return firebase.auth.TwitterAuthProvider;
    case 'microsoft':
      return firebase.auth.MicrosoftAuthProvider;
    default:
      throw Error('Invalid Provider');
  }
};

export default login;
