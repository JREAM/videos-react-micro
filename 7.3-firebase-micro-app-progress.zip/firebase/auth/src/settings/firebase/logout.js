import firebase from 'firebase/app';

/**
 * logout
 * @param {string} provider   string
 * @param {string} mode       (Default: popup) [popup|redirect]
 */
const logout = async () => {
  try {
    await firebase.auth().signOut();
    // @TODO Clear some kind of session/state/data/etc
  } catch (error) {
    alert(error.message);
  }
};

export default logout;
