import firebase from 'firebase/app';
import { getProvider } from '../../../../settings/firebase/login';


// describe('Test Login Provider', () => {
//   test('getProvider: Matches supplied argument', () => {
//     const result = getProvider('google');
//     expect(result).toBe('Google');
//   });

//   test('getProvider: Should fail with fake provider', () => {
//     const result = getProvider('robot');
//     expect(result).stringContaining('not');
//   });

// });
