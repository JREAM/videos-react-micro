import React from 'react';
import { shallow } from 'enzyme';

// Import
import Navigation from '../../components/Navigation';

describe('<Navigation />', () => {
  it('renders <Navigation /> component', () => {
    shallow(<Navigation />);
  });
});
