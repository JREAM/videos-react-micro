import React from 'react';
import { shallow } from 'enzyme';

// Import
import ErrorBoundary from '../../components/ErrorBoundary';

describe('<ErrorBoundary />', () => {
  it('renders <ErrorBoundary /> component', () => {
    shallow(<ErrorBoundary />);
  });
});
