import React from 'react';
import { shallow } from 'enzyme';

// Import
import Layout from '../../components/Layout';

const Fake = () => (<div>Fake Item</div>);

describe('<Layout />', () => {
  it('renders <Layout /> component', () => {
    shallow(<Layout title="Fake"><Fake /></Layout>);
  });
});
