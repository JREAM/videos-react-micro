import React from 'react';
import { shallow } from 'enzyme';

// Import
import Home from '../../pages/Home';

describe('<Home />', () => {
  it('renders <Home /> component', () => {
    shallow(<Home />);
  });
});
