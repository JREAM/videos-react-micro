import React from 'react';
import { shallow } from 'enzyme';

// Import
import Status from '../../pages/Status';

describe('<Status />', () => {
  it('renders <Status /> component', () => {
    shallow(<Status />);
  });
});
