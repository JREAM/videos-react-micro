import React from 'react';
import { mount } from 'enzyme';

// Import
import App from '../App';

describe('<App />', () => {
  it('renders <App /> component', () => {
    mount(<App />);
  });
});
