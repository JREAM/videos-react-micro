import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';

// Firebase Init
import './settings/firebase/config';

// Very Minimal Styles @TODO d
import 'font-awesome/css/font-awesome.min.css';
import 'milligram/dist/milligram.min.css';
import './assets/styles/main.scss';

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
