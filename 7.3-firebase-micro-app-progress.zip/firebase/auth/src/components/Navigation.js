import React from 'react';
import { NavLink } from 'react-router-dom';
import { PATH } from '../constants';

// import logout from '../settings/firebase/logout';

const Navigation = () => {

  const handleLogout = (event) => {
    event.preventDefault();
    // logout();
  };

return (
  <nav>
    <div className="container column-75">
      <div className="column">
        <NavLink exact to={PATH.HOME} activeClassName="active">
          Home
        </NavLink>
        <NavLink to={PATH.STATUS} activeClassName="active">
          Status
        </NavLink>
        <NavLink to={PATH.LOGIN} activeClassName="active">
          Login
        </NavLink>
        <a href="#logout" onClick={handleLogout}>Logout</a>
      </div>
    </div>
  </nav>
  );
};

export default Navigation;
