import React from 'react';
import Helmet from 'react-helmet';

import Navigation from './Navigation';

const Layout = ({ title, children }) => (
  <>
    <Helmet>
      <title>{title}</title>
      <meta name="charset" content="utf-8" />
    </Helmet>
    <div className="wrapper">
      <header className="header">
        <section>
          <Navigation title={title} />
        </section>
      </header>
      <main className="content">
        <div className="container">
          <h1 className="title">{title}</h1>
          {children}
        </div>
      </main>
    </div>
  </>
);

export default Layout;
