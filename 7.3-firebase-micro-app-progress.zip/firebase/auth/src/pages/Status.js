import React from 'react';
import Layout from '../components/Layout';

const Status = () => (
  <Layout title="Status">
    <p>
      This is a Status page to display anything.
    </p>
  </Layout>
);

export default Status;
