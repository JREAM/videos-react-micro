import React from 'react';
import Layout from '../components/Layout';

const Home = () => (
  <Layout title="Home">
    <p>
     Simple <b>template</b> making use of <b>milligram.io framework</b>.
     This is very basic, we create samples to remember parts and re-use them.
    </p>
  </Layout>
);

export default Home;
