import React, { Component } from 'react';
import Layout from '../components/Layout';

import login from '../settings/firebase/login';

export default class Login extends Component {

  handleLogin = (event) => {
    event.preventDefault();
    const user = login(event.target.name);
    // const user = login(event.target.name, 'redirect');
    console.log(user);
  }

  render () {
    return (
      <Layout title="Login">
        <p>
          Login to the site!

          <button onClick={this.handleLogin} name="google" className="is-google">
            <i className="fa fa-google"></i> Google
          </button>
          <button onClick={this.handleLogin} name="github" className="is-github">
            <i className="fa fa-github"></i> Github
          </button>
          <button onClick={this.handleLogin} name="facebook" className="is-facebook" disabled>
            <i className="fa fa-facebook"></i> Facebook
          </button>
          <button onClick={this.handleLogin} name="twitter" className="is-twitter" disabled>
            <i className="fa fa-twitter"></i> Twitter
          </button>

        </p>
      </Layout>
    );
  }

}
