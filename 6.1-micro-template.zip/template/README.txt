# TEMPLATE

This is a base template to follow along with building Micro-Apps in React.
We are using a minimal CSS framework called [milligram.io](https://milligram.io).

---

Open Source MIT

(C) 2019 Jesse Boyer
