import React from 'react';
import Layout from '../layouts/Layout';

const About = () => (
  <Layout title="About">
    <p>
      This is an about page. It is nothing more than a filler so that we have a route
      for our samples area. We may or may not use this -- it depends on our sample project!
    </p>
  </Layout>
);

export default About;
