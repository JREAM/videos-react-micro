import React from 'react';
import Layout from '../layouts/Layout';

const Home = () => (
  <Layout title="Template: Home">
    <p>
      This is where we place the main content
      of this base template.
    </p>
    <blockquote>
      We are using <b>milligram</b> as a base stylesheet, and our own overwrites in SCSS.
    </blockquote>
    <p>
      This is meant to be very basic. We have a <b>Simple Route</b>, a Layout HOC Component, and
      not much else. These are in place so we do not have to rewrite much creating <b>micro-apps</b>.
    </p>
  </Layout>
);

export default Home;
