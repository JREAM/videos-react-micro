import React, { Component } from 'react';
import Layout from '../layouts/Layout';

export default class ErrorBoundary extends Component {

  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    // You can also log the error to an error reporting service
    console.log(error);
    console.log(info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Layout title="Error">
          <h1>Something went wrong.</h1>
          <p>
            Since this is for local development please look in your Console (<code>CTRL + SHIFT + I</code>).
          </p>
        </Layout>
      );
    }

    return this.props.children;
  }

}
