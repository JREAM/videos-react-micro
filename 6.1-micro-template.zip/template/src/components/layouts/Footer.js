import React from 'react';

const Footer = () => (
  <footer className="footer">
    <section className="container">
      <p className="copyright">
        Open Source <a href="https://opensource.org/licenses/MIT">MIT</a>
        <br />&copy; 2019 Jesse Boyer
      </p>
    </section>
  </footer>
);

export default Footer;
