import React from 'react';
import { NavLink } from 'react-router-dom';
import { PATH } from '../../constants';

const Navigation = () => (
  <nav className="navigation">
    <div className="container">
      <div className="column">
        <NavLink exact to={PATH.HOME}
          activeClassName="active">Home</NavLink>
        <NavLink to={PATH.ABOUT} activeClassName="active">About</NavLink>
      </div>
    </div>
  </nav>
);

export default Navigation;
