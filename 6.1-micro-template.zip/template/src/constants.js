export const PATH = {
  HOME: '/',
  ABOUT: '/about',
};

export default {};
