import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';

import { PATH } from './constants';
import Home from './components/pages/Home';
import About from './components/pages/About';

export default class App extends Component {

  render = () => {
    return (
      <BrowserRouter>
        <Switch>
          <Route exact path={PATH.HOME}
            component={Home} />
          <Route path={PATH.ABOUT} component={About} />
        </Switch>
      </BrowserRouter>
    );
  }

}
