import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import ErrorBoundary from './components/misc/ErrorBoundary';
// Very Minimal Styles
import 'milligram/dist/milligram.min.css';
import './assets/styles/main.scss';

// Wrap existing app in Provider
ReactDOM.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
  document.getElementById('root')
);
