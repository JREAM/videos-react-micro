import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import Logo from '../assets/images/logo.svg';

const Navigation = (props) => {
  return (
    <nav className="navbar is-fixed-top">
      <div className="container">
        <div className="navbar-brand">
          <Link to="/" className="navbar-item">
            <img src={Logo} alt="Logo" width="60" />
            <span className="logo-text">Unit7</span>
          </Link>
          <span className="navbar-burger burger" data-target="navbarMenu">
            <span />
            <span />
            <span />
          </span>
        </div>
        <div className="navbar-menu" id="navbarMenu">
          <div className="navbar-end">
            <NavLink to="/" className="navbar-item" activeClassName="is-active">
              Home
            </NavLink>
            <NavLink to="/about" className="navbar-item" activeClassName="is-active">
              About
            </NavLink>
            <NavLink to="/signup" className="navbar-item" activeClassName="is-active">
              Signup
            </NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
