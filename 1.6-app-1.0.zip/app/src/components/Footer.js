import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <p className="has-text-right">&copy; 2019 - Jesse Boyer</p>
      </div>
    </footer>
  );
};

export default Footer;
