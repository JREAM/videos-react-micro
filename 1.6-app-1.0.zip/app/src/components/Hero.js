import React from 'react';
import propTypes from 'prop-types';

const Hero = (props) => {
  const { title, subtitle } = props;
  return (
    <section className="hero is-small is-bold is-primary">
      <div className="hero-body">
        <div className="container">
          <h1 className="title">{title}</h1>
          {subtitle ? <p className="subtitle">{subtitle}</p> : ''}
        </div>
      </div>
    </section>
  );
};

export default Hero;

Hero.propTypes = {
  title: propTypes.string.isRequired,
  subtitle: propTypes.string,
  size: propTypes.oneOf([ 'is-small', 'is-medium', 'is-large' ]),
  color: propTypes.oneOf([ 'is-primary', 'is-info', 'is-success', 'is-warning', 'is-danger', 'is-light', 'is-dark' ]),
  gradient: propTypes.bool,
};
