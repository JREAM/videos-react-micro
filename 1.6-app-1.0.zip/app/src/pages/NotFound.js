import React, { Component } from 'react';
import Layout from '../layouts/PublicLayout';

export default class NotFound extends Component {

  render() {
    return (
      <Layout title="NotFound">
        <main>This is the Notfound page.</main>
      </Layout>
    );
  }

}
