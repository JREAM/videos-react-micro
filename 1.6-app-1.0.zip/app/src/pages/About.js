import React, { Component } from 'react';
import Layout from '../layouts/PublicLayout';

export default class About extends Component {

  render() {
    return (
      <Layout title="About">
        <main>This is the about page.</main>
      </Layout>
    );
  }

}
