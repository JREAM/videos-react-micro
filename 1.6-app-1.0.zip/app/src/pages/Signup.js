import React, { Component } from 'react';
import Layout from '../layouts/AuthLayout';

export default class Signup extends Component {

  render() {
    return <Layout title="Signup" />;
  }

}
