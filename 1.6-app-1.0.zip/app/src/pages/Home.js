import React, { Component } from 'react';
import Layout from '../layouts/PublicLayout';

export default class Home extends Component {

  render() {
    const p = {
      subtitle: 'heyyo',
      size: 'is-medium',
      color: 'is-large',
    };
    return (
      <Layout title="Home" {...p}>
        <main>This is the home page.</main>
      </Layout>
    );
  }

}
