import React, { Component } from 'react';
import propTypes from 'prop-types';
import { Helmet } from 'react-helmet';

import Navigation from '../components/Navigation';
import Hero from '../components/Hero';
import Footer from '../components/Footer';

export default class PrivateLayout extends Component {

  static propTypes = {
    title: propTypes.string.isRequired,
    // subtitle: propTypes.string,
    children: propTypes.element.isRequired,
  };

  render() {
    const { title, children } = this.props;
    return (
      <>
        <Helmet>
          <meta
            data-react-helmet="true"
            name="viewport"
            content="width=device-width,minimum-scale=1.0,initial-scale=1"
          />
          <meta charSet="utf-8" />
          <title>{title}</title>
        </Helmet>
        <Navigation />
        <Hero title={title} />
        <section className="section main-content">
          <div className="container">
            <div className="column is-vcentered">{children}</div>
          </div>
        </section>
        <Footer />
      </>
    );
  }

}
