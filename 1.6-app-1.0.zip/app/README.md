# Development Notes

- [Development Notes](#development-notes)
  - [The Flow of React](#the-flow-of-react)
  - [Properties vs State](#properties-vs-state)
  - [Adding ESLint](#adding-eslint)
  - [Routing Details](#routing-details)
  - [Event List](#event-list)
    - [Common Event List**](#common-event-list)
      - [Events: Keyboard](#events-keyboard)
      - [Events: Focus](#events-focus)
      - [Events: Forms](#events-forms)
      - [Events: Mouse](#events-mouse)
      - [Event: Pointer](#event-pointer)
      - [Event: Select](#event-select)
      - [Event: UI Window](#event-ui-window)
      - [Event: UI Wheel](#event-ui-wheel)
    - [Event.target vs event.currentTarget](#eventtarget-vs-eventcurrenttarget)
- [State vs Props](#state-vs-props)
- [State](#state)
  - [Global State Library: MobX](#global-state-library-mobx)
  - [Global State Library: Unstated](#global-state-library-unstated)
- [Context API](#context-api)
- [Hooks](#hooks)
  - [Code Splitting, Better](#code-splitting-better)
- [Transitions](#transitions)

---

- **A Few React Features** (Out of **many**)
  - `TypeScript`; React can use it, I don't.
  - `Flow Type`; Like TypeScript, but I don't like it.
  - `PWA - Progressive Web Apps`; React Builds Them.
  - `React Native`; For Cell Phone Apps (Different Library)
  - `Electron`; For Cross-platform Desktop Apps, Same Library.

## The Flow of React

- `package.json` has a shortcut under `scripts` which starts the `App`; `react-scripts start`
  - That command loads the entry file, default is: `src/index.js`
    - `index.js` loads whatever we tell it, `App.js` Component by default, which we code to load every child-page.
      - (App can load anything we want)
    - From index.js -> App.js -> Every component, it's rendered into a browser friendly format. The final output is at `public/index.html`.
    - **Note**: When you are ready to go live, you use: `yarn build` to minify and compile everything much smaller.

## Properties vs State

- `Properties (props)` are Immutable; They cannot change.
  - You can define Defaults.
  - Available in Function or Class components.
  - Often passed from Parent to Child, eg: `<Page title="My Blog">` will contain `props.title` equal to myBlog.
- `State`: (Default) Built in State is local to given Component.
  - You can define Defaults.
  - Available only in the current component, unless you use Context (not  recommended) or pass it through other components to get to the one you want (_use redux_).
  - Available in Class components only (Stateless Components)
  - `Redux`; A better tool to save one global state without passing things down a daisy chain.

## Adding ESLint

- Add the `.eslintrc` file to your project root (The same place where `package.json` is located) if you don't have it. If you cannot see it, make sure
    you can see hidden files. Otherwise in a terminal type `ls -a` to see hidden dotfiles.
- Once you have your `.eslintrc` in place, add the following linter items:

```sh
# Don't add eslint itself React complains, as it has it already
yarn add -D eslint-config-{airbnb,prettier} eslint-plugin-{import,jsx-a11y,react}
```

  - If you have problems with eslint, please install these globally: `npm i -g eslint eslint-plugin-react`


## Routing Details

We are using `react-router-dom` the best router for navigation. Here are
the differences between some items.

- **Router** - Define Routes in one of these (BrowserRouter suggested)
  - You only have ONE of these _(Unless you split routes in separate files)_
  - `<BrowserRouter>` uses HTML5 History for URLs
  - `<HashRouter>` uses a hash (`#`) in the URL to know your route
  - `<MemoryRouter>` doesn't use the URL bar, uses memory and is more for testing.

- **Routes** Place this where you want your pages to render.
  - You should only have ONE of these.
  - `<Route>` renders the actual component based off a matching URL defined in one of the routers
  - `<Switch>` renders the actual component based off a matching URL defined in a <*Router>
  - **Whats Different?**:
    - `Route` renders more than one component if there are matches.
    - `Switch` only renders one. **You should probably use switch.**

- **Links** - Place these anywhere you want Links to match your defined Routes
  - You can have MANY of these anywhere.
  - `<Link>` The standard link that ties into a router
  - `<NavLink>` Identical to a <Link>, it only allows you to add styles
  - `<Redirect>` will redirect a 300-something like a server does

Best Example:

```js
// ---------------------------------------------------------
// ROUTER method
// ---------------------------------------------------------
<BrowserRouter>
 // Your Routes in here, see below
</BrowserRouter>

// ---------------------------------------------------------
// ROUTE definitions
// ---------------------------------------------------------
// Place this in a Parent Component you want your
// pages to appear (such as App.js)
// ---------------------------------------------------------
// You must include the actual components at the top of file.
<BrowserRouter>
  <Switch>
    <Route exact path="/" component={Home}/>
    <Route path="/about" component={About}/>
    <Route component={Error}/>
  </Switch>
</BrowserRouter>

// ---------------------------------------------------------
// LINKS anywhere (Is aware of the the above definitions)
// ---------------------------------------------------------
<Link to="/">Home</Link>
// or
<NavLink to="/" activeClassName="active">Home</NavLink>
```

There are some other Router types and more advanced topics that aren't needed.

## Event List

> Please visit [https://reactjs.org/docs/events.html#supported-events](https://reactjs.org/docs/events.html#supported-events) for supported events.

### Common Event List**
Here are some common events prior to document hopping.

#### Events: Keyboard
```
onKeyDown onKeyPress onKeyUp
```

#### Events: Focus
```
onFocus onBlur
```

#### Events: Forms
```
onChange onInput onInvalid onSubmit
```

#### Events: Mouse
```
onClick onContextMenu onDoubleClick onDrag onDragEnd onDragEnter onDragExit
onDragLeave onDragOver onDragStart onDrop onMouseDown onMouseEnter onMouseLeave
onMouseMove onMouseOut onMouseOver onMouseUp
```

#### Event: Pointer

```
onPointerDown onPointerMove onPointerUp onPointerCancel onGotPointerCapture
onLostPointerCapture onPointerEnter onPointerLeave onPointerOver onPointerOut
```

#### Event: Select
```
onSelect
```

#### Event: UI Window
```
onScroll
```

#### Event: UI Wheel
```
onWheel
```

### Event.target vs event.currentTarget

- `event.target` - Represents the element an event occured at.
- `event.currentTarget` - Represents the element an event is applying to

# State vs Props

- **Similarities**
  - Both are Javascript Objects
  - Both are Immutable (But, State is update via `setState()`)
  - Both have to do with whats Rendered.
- **Differences**
  - Props come from a PARENT component, they never travel from CHILD to PARENT.
  - State can re-render for changes
  - State can UPDATE, so passing METHODS makes anything possible to update a PARENT.
  - State is asynchronous (non-blocking)
- **Tricks**
  - You can be clever and pass state as a property

# State

State is great. It is used to make Components interactive, but it comes with rules.

- State is used to keep your app synced, interactive, alive; And, remember we have no real page reloads.
  - **Example**: It could be used to save the "state" of a user preferencing logging in he/she set. This would be quite convenient to handle by grabbing from any datastore/database and having it setup for the end-user.
  - **It helps to remember**: This is not a server-side app, we are using front-end so things are very different!
- **Rules for State**
  - State is encapsulated (or confined) within a Component, it is not global.
    - _This is why people use Redux, MobX, State Managers, and the like for larger applications_
  - State is only available in **Class Components** _(Except with Hooks; But, that's a little different)_
    - **Setting the State**
      - The **initial** state setup **IS** set with `this.state = {...}` or `state = {...}` when _(Outside a constructor)_
      - The **update** state is **NEVER** updated with  `this.state.key = value`. It's update with `this.setState()`
        - _Why?_ - Because React may bundle several updates together and then process them. React also needs to intelligently re-render **only changed** items, so we use a method.
  - **Asynchronous Can be Tricky**
    - State (and props) can be Asynchronous (We don't choose). This means a Component can finish rendering the DOM and the State (or props) did not finish before the render so we see no change. _(Good to keep this in mind)_
    - A solution the to the above is simple, we create a function, rather than a `setState` call only.
      - **Abstract**: `this.setState( (<prevState>, <prevProps>) => { ...<prevState>, <yourObject> });`
      - **Example**: `this.setState( (this.state, props) => { ...this.state, age: this.state.age + 1 });`


## Global State Library: MobX



## Global State Library: Unstated




# Context API

This sounds like a scary concept, I think the wording makes it sound like it could be a big complicated thing. Truth is,
it's really easy!










# Hooks

- **Rules**
  - Don’t call Hooks inside `loops`, `conditions`, or `nested` functions.
  - **Always** use Hooks at the top level of your React function.
  - You can create custom hooks.
- **Use Hooks**
  - `yarn add eslint-plugin-react-hooks@next`

```json
// Your ESLint configuration
{
  "plugins": ["react-hooks"],
  "rules": { "react-hooks/rules-of-hooks": "error" }
}
```














## Code Splitting, Better
react-loadable

# Transitions
yarn add react-metro react-transition-group-plus
I think we use Loadable or the router, easier.










---

  // https://jsonplaceholder.typicode.com/

  // ASYNC ASSYNC
  // To fix it, use a second form of setState() that accepts a function rather
  // than an object. That function will receive the previous state as the first argument,
  // and the props at the time the update is applied as the second argument:
  this.setState((state, props) => ({
    counter: state.counter + props.increment
  }));
  this.setState((prevState, props) => {
    return {counter: prevState.counter + props.step};
  })
  - setState is async so we WAIT until its done
    -

  async getData() {
    try {
      const res = await request.get('https://jsonplaceholder.typicode.com/users');
      console.log(res);

    } catch (err) {
      console.log(err);
    }
  };
import request from 'superagent';
<button onClick={this.getData} type="submit">Submit</button>

  this.setState({quantity: 2})
  (prevState, props) => stateChange
  onClick(evt) {
    evt.preventDefault();
    this.setState(...this.state, () => count += 1);
  }



---

(c) 2019 Jesse Boyer <jream.com>

