#a  Base Files

These are custom **starter** files I wrote for the most part, or tweaked heavily. It will make your development flow similar to mine.

I would encourage you to copy **all** files into your **root** folder (Overwrite them) - This way we have identical formatting, any errors will be identical as well.

If you want to change it you may, I only suggest you do it after the project, otherwise I cannot help a custom configuration. This configuration fixes some annoyances.

**PS**: It's **best** to use a terminal and type **ls -a** to see the hidden **.files** to include. To move those via CLI run:

### One Liner

(Dont move the `*.md` file, those are just instructions for this)

```SH
mv babelrc .. ; mv .eslintrc .. ; \
  mv .gitignore .. ; move package.json .. ; \
  mv prettier* ..; rm INSTRUCTIONS.md ; cd .. ; rmdir starter_files
```

---

Open Source MIT

(c) 2019 Jesse Boyer <https://jream.com>
